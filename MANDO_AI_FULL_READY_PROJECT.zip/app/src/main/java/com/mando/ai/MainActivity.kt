package com.mando.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var mode = "عام"

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) input.setText(text)
        }
    }

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> if (ok) startSpeech() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this) { tts.language = Locale("ar", "EG") }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(8,8,18))
            setPadding(18, 18, 18, 12)
        }

        val title = TextView(this).apply {
            text = "✦ MANDO AI"
            textSize = 27f
            setTextColor(android.graphics.Color.rgb(0,229,255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 2)
        }
        status = TextView(this).apply {
            text = "ذكاء اصطناعي • جاهز"
            textSize = 12f
            setTextColor(android.graphics.Color.rgb(154,154,181))
            gravity = Gravity.CENTER
            setPadding(0,0,0,14)
        }
        root.addView(title)
        root.addView(status)

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("عام","مبرمج","أمن سيبراني").forEach { m ->
            val b = Button(this).apply {
                text = m
                textSize = 12f
                setTextColor(android.graphics.Color.WHITE)
                setOnClickListener { mode = m; status.text = "الوضع الحالي: $m" }
            }
            modes.addView(b, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(4,0,4,8) })
        }
        root.addView(modes)

        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 8)
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply {
            hint = "اكتب رسالتك..."
            setHintTextColor(android.graphics.Color.DKGRAY)
            setTextColor(android.graphics.Color.WHITE)
            setSingleLine(false)
            setBackgroundColor(android.graphics.Color.rgb(18,18,37))
            setPadding(18, 10, 18, 10)
        }
        val mic = Button(this).apply { text = "🎙" ; setOnClickListener { requestMic() } }
        val send = Button(this).apply { text = "إرسال" ; setOnClickListener { sendMessage() } }
        row.addView(input, LinearLayout.LayoutParams(0, 60, 1f))
        row.addView(mic, LinearLayout.LayoutParams(58, 60))
        row.addView(send, LinearLayout.LayoutParams(82, 60))
        root.addView(row)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val image = Button(this).apply {
            text = "🖼 صورة"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                startActivityForResult(i, 900)
            }
        }
        val admin = Button(this).apply { text = "⚙ لوحة"; setOnClickListener { showAdmin() } }
        tools.addView(image, LinearLayout.LayoutParams(0, 50, 1f))
        tools.addView(admin, LinearLayout.LayoutParams(0, 50, 1f))
        root.addView(tools)

        setContentView(root)
        addBot("أهلًا بيك في MANDO AI 💙\nاختار الوضع واكتب سؤالك. التطبيق مجهز بواجهة احترافية ودعم صوت وصور ولوحة إدارة.")
    }

    private fun addBubble(text: String, user: Boolean) {
        val v = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(18, 14, 18, 14)
            setBackgroundColor(if (user) android.graphics.Color.rgb(25,70,82) else android.graphics.Color.rgb(18,18,37))
        }
        val p = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,8,0,8) }
        chat.addView(v, p)
    }

    private fun addBot(text: String) {
        addBubble(text, false)
    }

    private fun sendMessage() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        addBubble("أنت: $q", true)
        input.text.clear()
        // Production connection point: secure backend endpoint.
        addBot("تم استلام رسالتك في وضع «$mode».\n\nلجعل الردود ذكاءً اصطناعيًا حقيقيًا، اربط التطبيق بخادم MANDO AI الآمن الذي يضع مفتاح مزود الذكاء الاصطناعي خارج الـAPK.")
        status.text = "وضع $mode • الرد التجريبي المحلي"
    }

    private fun requestMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        } else startSpeech()
    }

    private fun startSpeech() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "اتكلم...")
        }
        speechLauncher.launch(i)
    }

    private fun showAdmin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,10,30,10) }
        val title = TextView(this).apply { text = "لوحة MANDO AI"; textSize = 22f; setTextColor(android.graphics.Color.WHITE) }
        val note = TextView(this).apply {
            text = "إعدادات المطور: اسم التطبيق، الوضع الافتراضي، ورسالة الترحيب.\nملاحظة: مفاتيح الـAPI لا تُحفظ هنا."
            setTextColor(android.graphics.Color.LTGRAY)
        }
        box.addView(title); box.addView(note)
        AlertDialog.Builder(this).setView(box).setPositiveButton("تم", null).show()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
